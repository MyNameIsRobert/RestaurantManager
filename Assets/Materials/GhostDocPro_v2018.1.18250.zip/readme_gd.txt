Note: If you have GhostDoc version earlier than v5.5 installed on VS2017, you need to uninstall it from Programs and Features prior to installing the VS2017 VSIX version.

To use as Visual Studio 2017 Plugin please install the
	- GhostDoc {edition}.v{version}.VS2017.Extension.vsix

To use the GhostDoc in VS2010 - VS2015 please install the
	- GhostDoc {edition}.v{version}.exe

(Entrpise Edition Only) To use the command line utilities of with or without the VS, regardless of the VS version, please install the
	- GhostDoc Enterprise.v{version}.exe

For more details, please see this KB article - http://support.submain.com/kb/a55/installing-codeit_right-for-visual-studio.aspx 

